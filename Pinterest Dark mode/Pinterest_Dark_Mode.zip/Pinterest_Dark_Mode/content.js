function isLightColor(rgbString) {
  const match = rgbString.match(/\d+/g);
  if (!match || match.length < 3) return false;
  const [r, g, b] = match.map(Number);
  return (r + g + b) / 3 > 200;
}

function isTabElement(el) {
  return el.closest('div.X8m.zDA.UK7.fxm.wm0') !== null;
}

function isSearchWrapper(el) {
  return (
    el.matches('[role="search"]') ||
    el.matches('[data-test-id="search-box"]') ||
    el.closest('[role="search"]') !== null
  );
}

function shouldSkip(el) {
  if (isTabElement(el)) return true;
  if (el.tagName === 'svg' || el.closest('svg') !== null) return true;
  if (el.tagName === 'IMG') return true;
  const testId = el.getAttribute('data-test-id') || '';
  if (testId.toLowerCase().includes('pin') || testId.toLowerCase().includes('board')) return true;
  if (el.closest('nav') !== null || el.closest('[role="navigation"]') !== null) return true;
  if (el.closest('[aria-label="Pinterest"]') !== null) return true;
  return false;
}

function applyDarkMode(el) {
  try {
    if (shouldSkip(el)) return;
    const style = window.getComputedStyle(el);
    if (isSearchWrapper(el)) {
      el.style.backgroundColor = '#1e1e1e';
      el.style.color = '#ffffff';
      return;
    }
    if (isLightColor(style.backgroundColor)) {
      el.style.backgroundColor = '#121212';
    }
    if (style.color === 'rgb(0, 0, 0)' || isLightColor(style.color)) {
      el.style.color = '#ffffff';
    }
  } catch (e) {}
}

function fixBoardHover() {
  document.querySelectorAll('[data-test-id="board-card"], [data-test-id="boardCard"]').forEach(el => {
    if (el.style.backgroundColor && isLightColor(el.style.backgroundColor)) {
      el.style.backgroundColor = '#1e1e1e';
    }
    el.querySelectorAll('*').forEach(child => {
      if (child.style.backgroundColor && isLightColor(child.style.backgroundColor)) {
        child.style.backgroundColor = '#1e1e1e';
      }
    });
  });

  document.querySelectorAll('[style*="background-color: rgb(255"]').forEach(el => {
    if (shouldSkip(el)) return;
    el.style.backgroundColor = '#1e1e1e';
  });

  document.querySelectorAll('[style*="background-color: white"], [style*="background: white"]').forEach(el => {
    if (shouldSkip(el)) return;
    el.style.backgroundColor = '#1e1e1e';
  });
}

function cleanTabStyles() {
  document.querySelectorAll('div.X8m.zDA.UK7.fxm.wm0').forEach(el => {
    if (el.style.backgroundColor) {
      el.style.backgroundColor = '';
    }
  });
}

function fixHeaderAndTabs() {
  document.querySelectorAll('[style*="background-color: rgb(255, 255, 255)"], [style*="background-color: white"], [style*="background: white"]').forEach(el => {
    if (el.closest('svg')) return;
    if (el.tagName === 'IMG') return;
    if (el.querySelector('img') && el.children.length === 1) return;
    el.style.backgroundColor = '#1e1e1e';
  });
}

function applyToAll() {
  document.querySelectorAll('*').forEach(applyDarkMode);
  cleanTabStyles();
  fixBoardHover();
  fixHeaderAndTabs();
}

const observer = new MutationObserver(() => {
  applyToAll();
});

requestAnimationFrame(() => {
  applyToAll();
  observer.observe(document.body, { childList: true, subtree: true, attributeFilter: ['style'] });
});
